# Esercizio 1C
Lettura

## Brief
Leggere il testo di Kleist e scrivere un commento e publiccarlo nel file README.md.

## Restrizioni
- 500-1000 caratteri

## Consegna
Pubblicare il commento sulla piattaforma GitHub nel file README.md.

## Struttura cartella
```
GIM/esercizio_1C
	README.md
``` 

